﻿namespace COSC2100_ICE4_RobertMacklem
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tlpSquaresTable = new System.Windows.Forms.TableLayoutPanel();
            this.lblSquare15 = new System.Windows.Forms.Label();
            this.lblSquare14 = new System.Windows.Forms.Label();
            this.lblSquare13 = new System.Windows.Forms.Label();
            this.lblSquare12 = new System.Windows.Forms.Label();
            this.lblSquare11 = new System.Windows.Forms.Label();
            this.lblSquare10 = new System.Windows.Forms.Label();
            this.lblSquare9 = new System.Windows.Forms.Label();
            this.lblSquare8 = new System.Windows.Forms.Label();
            this.lblSquare7 = new System.Windows.Forms.Label();
            this.lblSquare6 = new System.Windows.Forms.Label();
            this.lblSquare5 = new System.Windows.Forms.Label();
            this.lblSquare4 = new System.Windows.Forms.Label();
            this.lblSquare3 = new System.Windows.Forms.Label();
            this.lblSquare2 = new System.Windows.Forms.Label();
            this.lblSquare1 = new System.Windows.Forms.Label();
            this.lblSquare0 = new System.Windows.Forms.Label();
            this.tlpLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.lblPairsFound = new System.Windows.Forms.Label();
            this.tlpSquaresTable.SuspendLayout();
            this.tlpLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpSquaresTable
            // 
            this.tlpSquaresTable.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tlpSquaresTable.ColumnCount = 4;
            this.tlpSquaresTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.Controls.Add(this.lblSquare15, 3, 3);
            this.tlpSquaresTable.Controls.Add(this.lblSquare14, 2, 3);
            this.tlpSquaresTable.Controls.Add(this.lblSquare13, 1, 3);
            this.tlpSquaresTable.Controls.Add(this.lblSquare12, 0, 3);
            this.tlpSquaresTable.Controls.Add(this.lblSquare11, 3, 2);
            this.tlpSquaresTable.Controls.Add(this.lblSquare10, 2, 2);
            this.tlpSquaresTable.Controls.Add(this.lblSquare9, 1, 2);
            this.tlpSquaresTable.Controls.Add(this.lblSquare8, 0, 2);
            this.tlpSquaresTable.Controls.Add(this.lblSquare7, 3, 1);
            this.tlpSquaresTable.Controls.Add(this.lblSquare6, 2, 1);
            this.tlpSquaresTable.Controls.Add(this.lblSquare5, 1, 1);
            this.tlpSquaresTable.Controls.Add(this.lblSquare4, 0, 1);
            this.tlpSquaresTable.Controls.Add(this.lblSquare3, 3, 0);
            this.tlpSquaresTable.Controls.Add(this.lblSquare2, 2, 0);
            this.tlpSquaresTable.Controls.Add(this.lblSquare1, 1, 0);
            this.tlpSquaresTable.Controls.Add(this.lblSquare0, 0, 0);
            this.tlpSquaresTable.Location = new System.Drawing.Point(0, 80);
            this.tlpSquaresTable.Margin = new System.Windows.Forms.Padding(0);
            this.tlpSquaresTable.Name = "tlpSquaresTable";
            this.tlpSquaresTable.RowCount = 4;
            this.tlpSquaresTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSquaresTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSquaresTable.Size = new System.Drawing.Size(434, 381);
            this.tlpSquaresTable.TabIndex = 0;
            // 
            // lblSquare15
            // 
            this.lblSquare15.AutoSize = true;
            this.lblSquare15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare15.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare15.Location = new System.Drawing.Point(324, 285);
            this.lblSquare15.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare15.Name = "lblSquare15";
            this.lblSquare15.Size = new System.Drawing.Size(110, 96);
            this.lblSquare15.TabIndex = 16;
            this.lblSquare15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare15.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare14
            // 
            this.lblSquare14.AutoSize = true;
            this.lblSquare14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare14.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare14.Location = new System.Drawing.Point(216, 285);
            this.lblSquare14.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare14.Name = "lblSquare14";
            this.lblSquare14.Size = new System.Drawing.Size(108, 96);
            this.lblSquare14.TabIndex = 15;
            this.lblSquare14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare14.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare13
            // 
            this.lblSquare13.AutoSize = true;
            this.lblSquare13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare13.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare13.Location = new System.Drawing.Point(108, 285);
            this.lblSquare13.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare13.Name = "lblSquare13";
            this.lblSquare13.Size = new System.Drawing.Size(108, 96);
            this.lblSquare13.TabIndex = 14;
            this.lblSquare13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare13.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare12
            // 
            this.lblSquare12.AutoSize = true;
            this.lblSquare12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare12.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare12.Location = new System.Drawing.Point(0, 285);
            this.lblSquare12.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare12.Name = "lblSquare12";
            this.lblSquare12.Size = new System.Drawing.Size(108, 96);
            this.lblSquare12.TabIndex = 13;
            this.lblSquare12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare12.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare11
            // 
            this.lblSquare11.AutoSize = true;
            this.lblSquare11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare11.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare11.Location = new System.Drawing.Point(324, 190);
            this.lblSquare11.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare11.Name = "lblSquare11";
            this.lblSquare11.Size = new System.Drawing.Size(110, 95);
            this.lblSquare11.TabIndex = 12;
            this.lblSquare11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare11.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare10
            // 
            this.lblSquare10.AutoSize = true;
            this.lblSquare10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare10.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare10.Location = new System.Drawing.Point(216, 190);
            this.lblSquare10.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare10.Name = "lblSquare10";
            this.lblSquare10.Size = new System.Drawing.Size(108, 95);
            this.lblSquare10.TabIndex = 11;
            this.lblSquare10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare10.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare9
            // 
            this.lblSquare9.AutoSize = true;
            this.lblSquare9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare9.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare9.Location = new System.Drawing.Point(108, 190);
            this.lblSquare9.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare9.Name = "lblSquare9";
            this.lblSquare9.Size = new System.Drawing.Size(108, 95);
            this.lblSquare9.TabIndex = 10;
            this.lblSquare9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare9.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare8
            // 
            this.lblSquare8.AutoSize = true;
            this.lblSquare8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare8.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare8.Location = new System.Drawing.Point(0, 190);
            this.lblSquare8.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare8.Name = "lblSquare8";
            this.lblSquare8.Size = new System.Drawing.Size(108, 95);
            this.lblSquare8.TabIndex = 9;
            this.lblSquare8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare8.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare7
            // 
            this.lblSquare7.AutoSize = true;
            this.lblSquare7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare7.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare7.Location = new System.Drawing.Point(324, 95);
            this.lblSquare7.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare7.Name = "lblSquare7";
            this.lblSquare7.Size = new System.Drawing.Size(110, 95);
            this.lblSquare7.TabIndex = 8;
            this.lblSquare7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare7.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare6
            // 
            this.lblSquare6.AutoSize = true;
            this.lblSquare6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare6.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare6.Location = new System.Drawing.Point(216, 95);
            this.lblSquare6.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare6.Name = "lblSquare6";
            this.lblSquare6.Size = new System.Drawing.Size(108, 95);
            this.lblSquare6.TabIndex = 7;
            this.lblSquare6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare6.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare5
            // 
            this.lblSquare5.AutoSize = true;
            this.lblSquare5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare5.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare5.Location = new System.Drawing.Point(108, 95);
            this.lblSquare5.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare5.Name = "lblSquare5";
            this.lblSquare5.Size = new System.Drawing.Size(108, 95);
            this.lblSquare5.TabIndex = 6;
            this.lblSquare5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare5.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare4
            // 
            this.lblSquare4.AutoSize = true;
            this.lblSquare4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare4.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare4.Location = new System.Drawing.Point(0, 95);
            this.lblSquare4.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare4.Name = "lblSquare4";
            this.lblSquare4.Size = new System.Drawing.Size(108, 95);
            this.lblSquare4.TabIndex = 5;
            this.lblSquare4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare4.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare3
            // 
            this.lblSquare3.AutoSize = true;
            this.lblSquare3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare3.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare3.Location = new System.Drawing.Point(324, 0);
            this.lblSquare3.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare3.Name = "lblSquare3";
            this.lblSquare3.Size = new System.Drawing.Size(110, 95);
            this.lblSquare3.TabIndex = 4;
            this.lblSquare3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare3.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare2
            // 
            this.lblSquare2.AutoSize = true;
            this.lblSquare2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare2.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare2.Location = new System.Drawing.Point(216, 0);
            this.lblSquare2.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare2.Name = "lblSquare2";
            this.lblSquare2.Size = new System.Drawing.Size(108, 95);
            this.lblSquare2.TabIndex = 3;
            this.lblSquare2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare2.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare1
            // 
            this.lblSquare1.AutoSize = true;
            this.lblSquare1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare1.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare1.Location = new System.Drawing.Point(108, 0);
            this.lblSquare1.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare1.Name = "lblSquare1";
            this.lblSquare1.Size = new System.Drawing.Size(108, 95);
            this.lblSquare1.TabIndex = 2;
            this.lblSquare1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare1.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // lblSquare0
            // 
            this.lblSquare0.AutoSize = true;
            this.lblSquare0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSquare0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSquare0.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare0.Location = new System.Drawing.Point(0, 0);
            this.lblSquare0.Margin = new System.Windows.Forms.Padding(0);
            this.lblSquare0.Name = "lblSquare0";
            this.lblSquare0.Size = new System.Drawing.Size(108, 95);
            this.lblSquare0.TabIndex = 1;
            this.lblSquare0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSquare0.Click += new System.EventHandler(this.onSquareClicked);
            // 
            // tlpLayoutPanel
            // 
            this.tlpLayoutPanel.ColumnCount = 1;
            this.tlpLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpLayoutPanel.Controls.Add(this.tlpSquaresTable, 0, 1);
            this.tlpLayoutPanel.Controls.Add(this.lblPairsFound, 0, 0);
            this.tlpLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.tlpLayoutPanel.Name = "tlpLayoutPanel";
            this.tlpLayoutPanel.RowCount = 2;
            this.tlpLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tlpLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpLayoutPanel.Size = new System.Drawing.Size(434, 461);
            this.tlpLayoutPanel.TabIndex = 1;
            // 
            // lblPairsFound
            // 
            this.lblPairsFound.AutoSize = true;
            this.lblPairsFound.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPairsFound.Font = new System.Drawing.Font("NSimSun", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPairsFound.Location = new System.Drawing.Point(3, 0);
            this.lblPairsFound.Name = "lblPairsFound";
            this.lblPairsFound.Size = new System.Drawing.Size(428, 80);
            this.lblPairsFound.TabIndex = 1;
            this.lblPairsFound.Text = "Pairs Found: 0 of 8";
            this.lblPairsFound.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 461);
            this.Controls.Add(this.tlpLayoutPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(450, 490);
            this.Name = "frmMain";
            this.Text = "Emoji Matching — Robert Macklem";
            this.tlpSquaresTable.ResumeLayout(false);
            this.tlpSquaresTable.PerformLayout();
            this.tlpLayoutPanel.ResumeLayout(false);
            this.tlpLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpSquaresTable;
        private System.Windows.Forms.Label lblSquare0;
        private System.Windows.Forms.Label lblSquare15;
        private System.Windows.Forms.Label lblSquare14;
        private System.Windows.Forms.Label lblSquare13;
        private System.Windows.Forms.Label lblSquare12;
        private System.Windows.Forms.Label lblSquare11;
        private System.Windows.Forms.Label lblSquare10;
        private System.Windows.Forms.Label lblSquare9;
        private System.Windows.Forms.Label lblSquare8;
        private System.Windows.Forms.Label lblSquare7;
        private System.Windows.Forms.Label lblSquare6;
        private System.Windows.Forms.Label lblSquare5;
        private System.Windows.Forms.Label lblSquare4;
        private System.Windows.Forms.Label lblSquare3;
        private System.Windows.Forms.Label lblSquare2;
        private System.Windows.Forms.Label lblSquare1;
        private System.Windows.Forms.TableLayoutPanel tlpLayoutPanel;
        private System.Windows.Forms.Label lblPairsFound;
    }
}

